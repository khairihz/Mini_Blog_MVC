
<?php 
//ce fichier appelle le bon controlleur
 require('controller/frontend.php');

try
{
if(isset($_GET['action'])){
    if($_GET['action'] == 'listPosts'){
         listPosts();
     }

    elseif ($_GET['action'] == 'post') {
        if (isset($_GET['id']) && $_GET['id'] >0){
            post();
    }
    else{
        //Erreur ! On arrête tout , on envoie une exception , donc on saute directement au catch
        throw new Exception('Aucun identifiant de billet envoyé');
        }
    }
//call addComment from controller
    elseif ($_GET['action'] == 'addComment'){
    if(isset($_GET['id']) && $_GET['id']>0){
        if(!empty($_POST['author']) && !empty($_POST['comment'])){
                addcomment($_GET['id'], $_POST['author'], $_POST['comment']);
        }
        else{
            //AUTRE EXCEPTION
            throw new Exception('Tous les champs ne sont pas remplis!');
        }
    }
    else{
        throw new Exception('Aucun identifiant de billet envoyé');
        }
    }
        elseif ($_GET['action'] == 'showComment') {
            if (isset($_GET['id']) && $_GET['id'] > 0) {
                showComment();
            }
            else {
            throw new Exception('Aucun commentaire trouvé !');
            }
        }
        elseif ($_GET['action'] == 'editComment') {
            if (isset($_GET['id']) && $_GET['id'] > 0) {
                if (!empty($_POST['comment'])) {
                    editComment($_GET['id'], $_POST['comment']);   
                   }
                else {
                    throw new Exception('Tous les champs ne sont pas remplis !');
                }
            }
            else {
                throw new Exception('Aucun identifiant de billet envoyé');
            }
        }
}
 else{
     listPosts();
 }
 
}
catch(Exception $e) {// s'il y'a une erreur , alors ...
    echo'Erreur : ' .$e->getMessage();
}