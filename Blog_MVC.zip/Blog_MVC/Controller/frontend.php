<?php

//Chargement des classes
require_once("Model/PostManager.php");
require_once("Model/CommentManager.php");
use \Blog_MVC\Model\PostManager;
use \Blog_MVC\Model\CommentManager;

function listPosts()
{
    $postManager = new PostManager(); //Création d'un objet
    $posts = $postManager->getPosts(); //Appel d'une fonction de cet objet

    require('view/frontend/listPostsView.php');
}

function post()
{
    $postManager = new PostManager();
    $commentManager = new CommentManager();

    $post = $postManager->getPost($_GET['id']);
    $comments = $commentManager->getComments($_GET['id']);

    require('view/frontend/postView.php');
}

function addComment($postId, $author, $comment)
{
    $commentManager = new CommentManager();

    $affectedLines == $commentManager->postComment($postId, $author, $comment);

    if ($affectedLines ===false){
    // Erreur gérée. Elle sera remontée jusqu'au bloc try du routeur !
    throw new Exception('impossible d\'ajouter le commentaire!');
    }
    else{
        header('Location: index.php?action=post&id='.$postId);
    }}

    function showComment()
{
    $commentManager = new CommentManager();
    $comment = $commentManager->getComment($_GET['id']);
 
    require('view/frontend/editView.php');
}
 
 
function editComment($id, $comment)
{
    $commentManager = new CommentManager();
 
    $newComment = $commentManager->updateComment($id, $comment);
 
    if ($newComment === false) {
 
        throw new Exception('Impossible de modifier le commentaire !');
    }
    else {
        echo 'commentaire : ' . $_POST['comment'];
        header('Location: index.php?action=showComment&id=' . $id);
    }
}
